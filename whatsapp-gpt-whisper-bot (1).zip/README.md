# WhatsApp GPT-Whisper Bot
Bot WhatsApp che riceve messaggi vocali o testuali e risponde con GPT-4 dopo trascrizione con Whisper.